# Démarrage ultra-rapide

```bash
cd todo
composer install
php artisan migrate
php -S localhost:8000 -t public
```

C'est tout ! Ouvrez http://localhost:8000
