<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SimpleTodo - Liste de tâches</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background: white;
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .creator-only {
            display: none;
        }
        .creator-only.show {
            display: block !important;
        }
        .todo-container {
            max-width: 600px;
            margin: 50px auto;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }
        .card-header {
            background: linear-gradient(135deg, #8fa4f5 0%, #b491e8 100%);
            color: white;
            border-radius: 15px 15px 0 0 !important;
            padding: 20px;
        }
        .todo-item {
            padding: 15px;
            border-bottom: 1px solid #e9ecef;
            transition: background-color 0.2s;
        }
        .todo-item:hover {
            background-color: #f8f9fa;
        }
        .todo-item.completed {
            opacity: 0.6;
        }
        .todo-text.completed {
            text-decoration: line-through;
        }
        .pseudo-badge {
            font-size: 0.75rem;
            padding: 3px 8px;
            margin-left: 10px;
        }
        .btn-circle {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .input-group {
            margin-bottom: 20px;
        }
        .comments-section {
            margin-top: 10px;
            padding-top: 10px;
            border-top: 1px solid #e9ecef;
        }
        .comment-item {
            padding: 8px;
            margin-bottom: 5px;
            background-color: #f8f9fa;
            border-radius: 5px;
            font-size: 0.9rem;
        }
        .comment-pseudo {
            font-weight: bold;
            color: #667eea;
            font-size: 0.85rem;
        }
        .comment-form {
            margin-top: 10px;
        }
        .btn-comment {
            font-size: 0.85rem;
            margin-right: 0.5rem;
        }
        .comment-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: #dc3545;
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        .btn-comment-wrapper {
            position: relative;
        }
        .accordion-item {
            border: 1px solid #dee2e6;
            margin-top: 10px;
            border-radius: 8px;
            overflow: hidden;
        }
        .accordion-button {
            background-color: #f8f9fa;
            padding: 12px 15px;
        }
        .accordion-button:not(.collapsed) {
            background-color: #e7f3ff;
            color: #0a58ca;
        }
        .accordion-body {
            padding: 0 !important;
        }
        .accordion-button .badge {
            margin-right: 8px;
        }
        #categoriesContainer {
            max-height: 200px;
            overflow-y: auto;
        }
        #categoriesContainer .badge {
            font-size: 0.75rem;
            padding: 4px 8px;
        }
        .todo-item .btn, .todo-item .btn-wrapper, .todo-item input {
            pointer-events: auto;
        }
        .accordion-body {
            pointer-events: none;
        }
        .accordion-body * {
            pointer-events: auto;
        }
        /* Masquer les sections créateur pour les non-créateurs */
    </style>
</head>
<body>
    <div class="container todo-container">
        <div class="card">
            <div class="card-header">
                <div class="d-flex align-items-center mb-3">
                    <h4 class="mb-0"><i class="bi bi-check2-square"></i> <span id="listTitle">SimpleTodo</span></h4>
                    <div class="d-flex gap-2 ms-auto">
                        <button class="btn btn-sm btn-light creator-only" onclick="editTitle()">
                            <i class="bi bi-pencil"></i> Modifier
                        </button>
                        <button class="btn btn-sm btn-outline-light" data-bs-toggle="modal" data-bs-target="#helpModal">
                            <i class="bi bi-question-circle"></i> Aide
                        </button>
                    </div>
                </div>
                <div id="titleInput" style="display: none;" class="mb-3">
                    <div class="input-group">
                        <input type="text" id="titleField" class="form-control" placeholder="Titre de la liste" maxlength="100">
                        <button class="btn btn-light" onclick="saveTitle()">
                            <i class="bi bi-check-lg"></i> Sauvegarder
                        </button>
                        <button class="btn btn-light" onclick="cancelTitleEdit()">
                            <i class="bi bi-x-lg"></i> Annuler
                        </button>
                    </div>
                </div>
                
                <!-- Pseudo et Email actuels -->
                <div id="userInfo" class="d-flex align-items-center mb-2" style="display: none;">
                    <span class="text-white"><i class="bi bi-person-circle"></i> <span id="currentPseudo"></span></span>
                    <span class="text-white ms-3" id="emailBadge" style="display: none;"><i class="bi bi-envelope-check"></i> Notifications</span>
                    <button class="btn btn-sm btn-light ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#userSettings">
                        <i class="bi bi-gear"></i>
                    </button>
                </div>
                
                <!-- Collapse pour modifier pseudo et email -->
                <div class="collapse" id="userSettings">
                    <div class="input-group input-group-lg mb-3">
                        <input type="text" id="pseudo" class="form-control" placeholder="Votre pseudo" maxlength="50">
                        <button class="btn btn-light" onclick="savePseudo()">
                            <i class="bi bi-check-lg"></i> Enregistrer
                        </button>
                    </div>
                    
                    <div>
                        <small class="text-white d-block mb-2">📧 Recevoir les notifications</small>
                        <div id="emailSubscription">
                            <div class="input-group input-group-sm mb-2">
                                <input type="email" id="email" class="form-control" placeholder="votre@email.com" maxlength="255">
                                <button class="btn btn-light btn-sm" onclick="subscribe()">
                                    <i class="bi bi-bell"></i> S'inscrire
                                </button>
                            </div>
                        </div>
                        <div id="emailUnsubscribe" style="display: none;">
                            <div class="input-group input-group-sm mb-2">
                                <span class="form-control bg-light text-dark" id="emailDisplay"></span>
                                <button class="btn btn-light btn-sm" onclick="unsubscribe()">
                                    <i class="bi bi-bell-slash"></i> Se désinscrire
                                </button>
                            </div>
                        </div>
                        <small class="text-white">Vous serez notifié des nouvelles tâches et des tâches terminées</small>
                    </div>

                    <!-- Liste des abonnés -->
                    <div class="border-top border-white mt-3 pt-3">
                        <small class="text-white d-block mb-2">👥 Abonnés à cette liste</small>
                        <div id="subscribersList" class="border-top border-white pt-2">
                            <div class="text-white small text-center py-2">
                                <i class="bi bi-hourglass-split"></i> Chargement...
                            </div>
                        </div>
                    </div>

                    <!-- Inviter quelqu'un -->
                    <div class="border-top border-white mt-3 pt-3">
                        <small class="text-white d-block mb-2">✉️ Inviter quelqu'un</small>
                        <div class="input-group input-group-sm mb-2">
                            <input type="email" id="inviteEmail" class="form-control" placeholder="email@example.com" maxlength="255">
                            <button class="btn btn-light btn-sm" onclick="inviteCollaborator()">
                                <i class="bi bi-send"></i> Inviter
                            </button>
                        </div>
                        <small class="text-white">Ils recevront un email avec le lien vers la liste</small>
                    </div>

                    <!-- Gestion des catégories (créateur uniquement) -->
                    <div class="border-top border-white mt-3 pt-3 creator-only">
                        <small class="text-white d-block mb-2">🏷️ Gestion des catégories</small>
                        
                        <div class="mb-3">
                            <label class="text-white small d-block mb-1">Nouvelle catégorie</label>
                            <div class="input-group input-group-sm mb-2">
                                <input type="text" id="newCategoryName" class="form-control" placeholder="Nom de la catégorie" maxlength="100">
                                <input type="color" id="newCategoryColor" class="form-control form-control-color" value="#007bff" style="max-width: 60px;">
                                <button class="btn btn-light btn-sm" onclick="addCategory()">
                                    <i class="bi bi-plus"></i> Ajouter
                                </button>
                            </div>
                        </div>

                        <div id="categoriesList">
                            <label class="text-white small d-block mb-1">Catégories existantes</label>
                            <div id="categoriesContainer" class="border-top border-white pt-2"></div>
                        </div>
                    </div>

                    <!-- Personnalisation du thème (créateur uniquement) -->
                    <div class="border-top border-white mt-3 pt-3 creator-only">
                        <small class="text-white d-block mb-2">🎨 Thème du header</small>
                        <select id="headerGradient" class="form-select form-select-sm mb-2" onchange="changeHeaderGradient()">
                            <option value="gradient1">Bleu/Violet clair</option>
                            <option value="gradient2">Rouge/Orange</option>
                            <option value="gradient3">Vert/Menthe</option>
                            <option value="gradient4">Bleu clair/Cyan</option>
                            <option value="gradient5">Rose/Violet</option>
                            <option value="gradient6">Bleu foncé/Violet foncé</option>
                            <option value="gradient7">Orange/Jaune</option>
                            <option value="gradient8">Violet foncé/Rose</option>
                        </select>
                    </div>

                    <!-- Option d'assignation automatique (créateur uniquement) -->
                    <div class="border-top border-white mt-3 pt-3 creator-only">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="autoAssignToCreator" onchange="saveAutoAssignOption()">
                            <label class="form-check-label text-white" for="autoAssignToCreator">
                                <small>📋 Assigner automatiquement les nouvelles tâches au créateur</small>
                            </label>
                        </div>
                        <small class="text-white d-block mt-1">Les nouvelles tâches seront automatiquement assignées au créateur</small>
                    </div>

                    <!-- Supprimer les tâches terminées (créateur uniquement) -->
                    <div class="border-top border-white mt-3 pt-3 creator-only">
                        <small class="text-white d-block mb-2">🗑️ Nettoyage</small>
                        <button class="btn btn-sm btn-light w-100 mb-2" onclick="clearCompleted()" id="clearBtn" style="display: none;">
                            <i class="bi bi-trash"></i> Supprimer les tâches terminées
                        </button>
                        <small class="text-white d-block mb-2">Supprime toutes les tâches marquées comme complétées</small>
                        
                        <!-- Supprimer la liste (créateur uniquement) -->
                        <button class="btn btn-sm btn-danger w-100 d-none" id="deleteListBtnSettings" onclick="confirmDeleteList()">
                            <i class="bi bi-trash3"></i> Supprimer la liste
                        </button>
                        <small class="text-white d-block mt-2">⚠️ Action irréversible - La liste et toutes ses données seront supprimées</small>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="input-group mb-3">
                    <input type="text" id="todoInput" class="form-control form-control-lg" placeholder="Ajouter une tâche..." maxlength="255">
                    <button class="btn btn-primary" onclick="addTodo()">
                        <i class="bi bi-plus-lg"></i> Ajouter
                    </button>
                </div>
                
                <div id="stats" class="mb-3">
                    <small class="text-muted">
                        <span id="totalCount">0</span> tâche(s) au total
                        <span id="completedCount">0</span> terminée(s)
                    </small>
                </div>

                <div id="todoList">
                    <div class="text-center text-muted py-5">
                        <i class="bi bi-inbox" style="font-size: 3rem;"></i>
                        <p class="mt-3">Aucune tâche pour le moment</p>
                    </div>
                </div>
                
                <!-- Bouton de partage en bas -->
                <div class="text-center py-3 border-top">
                    <button class="btn btn-outline-primary" onclick="shareListUrl()">
                        <i class="bi bi-share"></i> Partager cette liste
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="container mt-4 text-center">
        <small class="text-muted">
            <a href="#" class="creator-only" data-bs-toggle="modal" data-bs-target="#updateModal">Mettre à jour l'application</a>
        </small>
    </div>

    <!-- Modal de mise à jour (propriétaire uniquement) -->
    <div class="modal fade" id="updateModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-arrow-repeat"></i> Mise à jour de l'application</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-2">Exécute le script d'update côté serveur et affiche le résultat ici.</p>
                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input" type="checkbox" id="updateForce">
                        <label class="form-check-label" for="updateForce">Forcer (écraser les modifications locales en cas de conflit)</label>
                    </div>
                    <div id="updateStatus" class="mb-2 text-muted" style="display:none"></div>
                    <pre id="updateOutput" class="bg-dark text-white p-3 rounded" style="max-height: 300px; overflow: auto;">Prêt.</pre>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                    <button type="button" class="btn btn-primary" onclick="runServerUpdate()"><i class="bi bi-play-circle"></i> Lancer la mise à jour</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal d'aide -->
    <div class="modal" id="helpModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="bi bi-question-circle"></i> Aide - Utilisation de SimpleTodo</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <h6 class="fw-bold"><i class="bi bi-list-check"></i> Gestion des tâches</h6>
                    <ul class="list-unstyled ms-3">
                        <li><i class="bi bi-plus-circle text-success"></i> <strong>Ajouter une tâche :</strong> Utilisez le champ de saisie en bas de la page, puis cliquez sur "Ajouter".</li>
                        <li><i class="bi bi-check-circle text-primary"></i> <strong>Marquer comme terminée :</strong> Cliquez sur le bouton rond pour marquer une tâche comme complétée.</li>
                        <li><i class="bi bi-three-dots text-secondary"></i> <strong>Actions sur une tâche :</strong> Cliquez sur le menu (⋯) pour accéder aux actions :
                            <ul class="ms-3 mt-2">
                                <li><i class="bi bi-person-plus text-success"></i> <strong>Je m'en occupe :</strong> Assignez-vous une tâche (si elle n'est pas déjà assignée)</li>
                                <li><i class="bi bi-tag text-warning"></i> <strong>Changer de catégorie :</strong> Déplacez une tâche dans une autre catégorie</li>
                                <li><i class="bi bi-calendar-plus text-secondary"></i> <strong>Modifier la date d'échéance :</strong> Ajoutez ou modifiez une date d'échéance pour une tâche</li>
                                <li><i class="bi bi-trash text-danger"></i> <strong>Supprimer :</strong> Supprimez définitivement une tâche</li>
                            </ul>
                        </li>
                        <li><i class="bi bi-chat-left text-info"></i> <strong>Commenter :</strong> Cliquez sur l'icône de message pour ajouter des commentaires à une tâche.</li>
                    </ul>

                    <hr>

                    <h6 class="fw-bold"><i class="bi bi-tags"></i> Catégories</h6>
                    <p>Organisez vos tâches par catégories :</p>
                    <ul class="ms-3">
                        <li>Dans les <strong>paramètres</strong> (<i class="bi bi-gear"></i>), accédez à la gestion des catégories</li>
                        <li>Créez des catégories avec une couleur personnalisée</li>
                        <li>Les tâches sont automatiquement regroupées par catégorie dans des accordions</li>
                        <li>Ajoutez une tâche sans catégorie, puis <strong>changez-la plus tard</strong> avec le bouton tag orange</li>
                    </ul>

                    <hr>

                    <h6 class="fw-bold"><i class="bi bi-gear"></i> Paramètres</h6>
                    <p>Cliquez sur l'icône <i class="bi bi-gear"></i> pour accéder aux paramètres :</p>
                    <ul class="ms-3">
                        <li><strong>Pseudo :</strong> Personnalisez votre pseudo affiché sur vos actions</li>
                        <li><strong>Thème du header :</strong> Choisissez un gradient de couleur pour le header (persistant)</li>
                        <li><strong>Notifications email :</strong> Inscrivez-vous pour recevoir des alertes par email sur les nouvelles tâches et les tâches terminées. Un email de bienvenue sera envoyé avec un lien unique.</li>
                        <li><strong>Liste des abonnés :</strong> Consultez qui est abonné aux notifications de cette liste, avec possibilité de renvoyer le lien</li>
                        <li><strong>Inviter quelqu'un :</strong> Envoyez un email d'invitation à un collaborateur avec le lien direct vers la liste</li>
                        <li><strong>Catégories :</strong> Gérez vos catégories (création, suppression)</li>
                        <li><strong>Nettoyage :</strong> Supprimez toutes les tâches terminées en un clic</li>
                    </ul>

                    <hr>

                    <h6 class="fw-bold"><i class="bi bi-bell"></i> Notifications par email</h6>
                    <ul class="ms-3">
                        <li><strong>Inscription :</strong> Abonnez-vous pour recevoir des notifications par email</li>
                        <li><strong>Email de bienvenue :</strong> Vous recevrez un email avec un lien unique vers la liste</li>
                        <li><strong>Nouvelles tâches :</strong> Notification automatique quand une tâche est ajoutée</li>
                        <li><strong>Tâches terminées :</strong> Notification quand une tâche est marquée comme complétée</li>
                        <li><strong>Désinscription :</strong> Annulez vos notifications via le bouton dans les paramètres</li>
                    </ul>

                    <hr>

                    <h6 class="fw-bold"><i class="bi bi-envelope"></i> Invitation par email</h6>
                    <ul class="ms-3">
                        <li><strong>Inviter :</strong> Dans les paramètres, section "Inviter quelqu'un"</li>
                        <li><strong>Email d'invitation :</strong> Envoyez un email avec votre nom et le lien vers la liste</li>
                        <li><strong>Accès direct :</strong> L'invité clique sur le lien et accède immédiatement à la liste</li>
                        <li><strong>Sans inscription :</strong> Aucune inscription nécessaire pour collaborer</li>
                    </ul>

                    <hr>

                    <h6 class="fw-bold"><i class="bi bi-link-45deg"></i> Partage</h6>
                    <ul class="ms-3">
                        <li><i class="bi bi-share text-primary"></i> <strong>Bouton Partager :</strong> Cliquez sur le bouton "Partager" en bas de la liste pour copier le lien de la liste (sans token). Partagez-le avec vos collaborateurs pour qu'ils puissent accéder à la liste.</li>
                        <li><i class="bi bi-envelope text-success"></i> <strong>Invitation par email :</strong> Utilisez la section "Inviter quelqu'un" dans les paramètres pour envoyer un email avec un lien direct vers la liste.</li>
                        <li><strong>Liens de notification :</strong> Les abonnés aux notifications reçoivent des emails avec des liens tokenisés qui les reconnectent automatiquement.</li>
                    </ul>

                    <hr>

                    <h6 class="fw-bold"><i class="bi bi-info-circle"></i> Conseils</h6>
                    <ul class="ms-3">
                        <li>Utilisez les catégories pour organiser vos tâches par projet ou priorité</li>
                        <li>Les tâches assignées affichent le nom de la personne qui s'en occupe</li>
                        <li><strong>C'est le créateur ?</strong> Vous pouvez modifier le titre, changer le thème, supprimer les tâches terminées ou même supprimer la liste.</li>
                        <li>Les commentaires permettent d'ajouter des détails ou de discuter sur une tâche</li>
                        <li>Abonnez-vous aux notifications pour rester informé des changements</li>
                        <li>Partagez le lien de la liste avec le bouton "Partager" en bas</li>
                        <li>Invitez vos collaborateurs par email pour faciliter l'accès à la liste</li>
                        <li>Les emails incluent des liens directs vers la liste pour un accès facile</li>
                        <li>Les dates d'échéance permettent de prioriser vos tâches</li>
                    </ul>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal pour le pseudo -->
    <div class="modal" id="pseudoModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-person-circle"></i> Bienvenue !</h5>
                </div>
                <div class="modal-body">
                    <p>Pour participer à cette liste de tâches, veuillez entrer votre pseudo :</p>
                    <div class="input-group">
                        <input type="text" id="modalPseudo" class="form-control" placeholder="Votre pseudo" maxlength="50">
                        <button class="btn btn-primary" onclick="savePseudoFromModal()">
                            <i class="bi bi-check-lg"></i> Continuer
                        </button>
                    </div>
                    <small class="text-muted d-block mt-2">Ce pseudo sera stocké localement et affiché avec vos tâches</small>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Injecter les données PHP dans le JavaScript
        window.userEmail = @json($email);
        window.csrfToken = '<?php echo isset($_SESSION['csrf_token']) ? $_SESSION['csrf_token'] : ''; ?>';
    </script>
    
    <script src="/js/app.js"></script>
</body>
</html>
